### CS352
Internet Technology Fall 2020

# Project 1
*Currently implemented: (11/20/2020)* by,
- Sujay Sayini ss3214
- Aries Regalado alr251

## How to run
1. ```javac HTTP1Server```
2. ```java HTTP1Server 3456```
3. ```java -jar HTTPServerTester.jar localhost 3456```

## Structure:

* *project_root* -> README.md
* *project_root* -> HttpServerTester.jar
* *project_root* -> HTTP1Server.java

